function filterGuides(category, btn) {
  if (typeof stopSpeech === 'function') stopSpeech();
  currentGuideFilter = category;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');

  const sections = document.querySelectorAll('.guide-section');
  sections.forEach(sec => {
    if (category === 'all') {
      sec.style.display = 'block';
    } else {
      sec.style.display = sec.id === `guide-${category}` ? 'block' : 'none';
    }
  });
}

function initGoBagState() {
  for (let i = 1; i <= 6; i++) {
    const isChecked = localStorage.getItem(`gobag_item${i}`) === 'true';
    const checkbox = document.getElementById(`item${i}`);
    if (checkbox) {
      checkbox.checked = isChecked;
      if (isChecked) checkbox.parentElement.classList.add('checked');
    }
  }
  updateGoBagProgress();
}

function toggleGoBag(itemId) {
  const checkbox = document.getElementById(itemId);
  if (!checkbox) return;
  
  const isChecked = checkbox.checked;
  checkbox.parentElement.classList.toggle('checked', isChecked);
  localStorage.setItem(`gobag_${itemId}`, isChecked);
  updateGoBagProgress();
}

function updateGoBagProgress() {
  let count = 0;
  for (let i = 1; i <= 6; i++) {
    if (localStorage.getItem(`gobag_item${i}`) === 'true') count++;
  }
  document.getElementById('gobagProgress').innerText = window.gobagLabel ? window.gobagLabel(count) : `${count}/6 Packed`;
}
