var guideLang = 'en';
try { guideLang = localStorage.getItem('guideLang') === 'fil' ? 'fil' : 'en'; } catch (e) {}
var currentGuideFilter = 'all';
var ttsTexts = {};

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function ttsBtn(key) {
  if (!TTS_OK) return "";
  var label = GUI.readAloud[guideLang];
  return '<button type="button" class="tts-btn" onclick="ttsToggle(this,\'' + key + '\')" aria-label="' + label + '" title="' + label + '">' +
         '<i data-lucide="volume-2" class="ico-play"></i><i data-lucide="square" class="ico-stop"></i></button>';
}

function stepHTML(step, i) {
  var inner = step.p
    ? '<h5>' + esc(step.h[guideLang]) + '</h5><p>' + esc(step.p[guideLang]) + '</p>'
    : '<p class="plain">' + esc(step[guideLang]) + '</p>';
  return '<div class="step-card"><div class="step-number">' + (i + 1) + '</div><div class="step-content">' + inner + '</div></div>';
}

function stepText(step, i) {
  return GUI.step[guideLang] + ' ' + (i + 1) + '. ' + (step.p ? step.h[guideLang] + '. ' + step.p[guideLang] : step[guideLang]);
}

function subHTML(sec, sub) {
  var L = guideLang, key = sec + ':' + sub.id;
  var txt = sub.title[L] + '. ', body = '';
  if (sub.cause) { body += '<p class="sub-note">' + esc(sub.cause[L]) + '</p>'; txt += sub.cause[L] + ' '; }
  sub.steps.forEach(function (s, i) { body += stepHTML(s, i); txt += stepText(s, i) + ' '; });
  if (sub.warn) { body += '<div class="warn-line">⚠️ ' + esc(sub.warn[L]) + '</div>'; txt += sub.warn[L]; }
  ttsTexts[key] = txt;
  return '<div class="sub-item" id="sub-' + sec + '-' + sub.id + '">' +
           '<div class="sub-head">' +
             '<button type="button" class="sub-toggle" onclick="toggleSub(this)" aria-expanded="false">' +
               '<span class="sub-icon">' + sub.icon + '</span><span class="sub-title">' + esc(sub.title[L]) + '</span>' +
               '<i data-lucide="chevron-down" class="chev"></i></button>' +
             ttsBtn(key) +
           '</div>' +
           '<div class="sub-body">' + body + '</div>' +
         '</div>';
}

function sectionHTML(sec) {
  var L = guideLang, def = GUIDES[sec];
  var txt = def.title[L] + '. ' + (def.intro ? def.intro[L] + ' ' : '');
  var inner = def.intro ? '<p class="sub-note" style="margin-bottom:10px;">' + esc(def.intro[L]) + '</p>' : '';
  def.subs.forEach(function (sub) { inner += subHTML(sec, sub); txt += ttsTexts[sec + ':' + sub.id] + ' '; });
  ttsTexts[sec] = txt;
  return '<div class="card guide-section" id="guide-' + sec + '">' +
           '<div class="guide-title-row" style="margin-bottom:8px;"><div class="card-title">' + esc(def.title[L]) + '</div>' + ttsBtn(sec) + '</div>' +
           inner + '</div>';
}

function goBagHTML() {
  var L = guideLang, d = GUIDES.gobag;
  var txt = d.title[L] + '. ' + d.sub[L] + '. ', items = '';
  d.items.forEach(function (it, i) {
    var n = i + 1;
    items += '<label class="checklist-item" onclick="toggleGoBag(\'item' + n + '\')">' +
             '<input type="checkbox" id="item' + n + '"><span style="font-size:0.85rem;">' + esc(it[L]) + '</span></label>';
    txt += it[L] + '. ';
  });
  ttsTexts.gobag = txt;
  return '<div class="card guide-section" id="guide-gobag">' +
           '<div class="card-header"><div>' +
             '<div class="guide-title-row"><div class="card-title">' + esc(d.title[L]) + '</div>' + ttsBtn('gobag') + '</div>' +
             '<p style="font-size:0.75rem; color:var(--text-muted);">' + esc(d.sub[L]) + '</p>' +
           '</div><span style="font-size:0.75rem; font-weight:600; color:var(--info);" id="gobagProgress">0/6 ' + GUI.packed[L] + '</span></div>' +
           '<div id="checklistContainer">' + items + '</div></div>';
}

function hotlinesHTML() {
  var L = guideLang, d = GUIDES.hotlines;
  var txt = d.title[L] + '. ', rows = '';
  d.items.forEach(function (h) {
    rows += '<a href="tel:' + h.tel + '" class="btn-secondary" style="text-decoration:none; justify-content:space-between;">' +
            '<span><i data-lucide="' + h.icon + '" style="width:16px;"></i> ' + esc(h.name[L]) + '</span>' +
            '<span style="color:var(--info);">' + h.shown + '</span></a>';
    var spoken = h.shown.split('-').map(function (g) { return g.split('').join(' '); }).join(', ');
    txt += h.name[L] + ', ' + spoken + '. ';
  });
  ttsTexts.hotlines = txt;
  return '<div class="card guide-section" id="guide-hotlines">' +
           '<div class="guide-title-row" style="margin-bottom:12px;"><div class="card-title">' + esc(d.title[L]) + '</div>' + ttsBtn('hotlines') + '</div>' +
           '<div style="display:flex; flex-direction:column; gap:10px;">' + rows + '</div></div>';
}

function applyGuideFilter() {
  document.querySelectorAll('.guide-section').forEach(function (sec) {
    sec.style.display = (currentGuideFilter === 'all' || sec.id === 'guide-' + currentGuideFilter) ? 'block' : 'none';
  });
}

function renderGuides() {
  var box = document.getElementById('guidesContainer');
  if (!box) return;
  var L = guideLang;

  // remember which subtopics were open
  var open = [].map.call(box.querySelectorAll('.sub-item.open'), function (e) { return e.id; });

  ttsTexts = {};
  box.innerHTML = goBagHTML() + sectionHTML('surge') + sectionHTML('firstaid') + hotlinesHTML();

  open.forEach(function (id) {
    var el = document.getElementById(id);
    if (el) { el.classList.add('open'); el.querySelector('.sub-toggle').setAttribute('aria-expanded', 'true'); }
  });

  // labels
  document.getElementById('guidesHeading').textContent = GUI.heading[L];
  document.getElementById('langEN').classList.toggle('active', L === 'en');
  document.getElementById('langFIL').classList.toggle('active', L === 'fil');
  document.querySelectorAll('[data-chip]').forEach(function (c) { c.textContent = GUI.chips[c.getAttribute('data-chip')][L]; });

  if (window.lucide) lucide.createIcons();
  applyGuideFilter();
  if (typeof initGoBagState === 'function') initGoBagState();
}

function toggleSub(btn) {
  var item = btn.closest('.sub-item');
  var isOpen = item.classList.toggle('open');
  btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
}

function setGuideLang(l) {
  stopSpeech();
  guideLang = (l === 'fil') ? 'fil' : 'en';
  try { localStorage.setItem('guideLang', guideLang); } catch (e) {}
  renderGuides();
}

// gives the go-bag counter its translated label
window.gobagLabel = function (n) { return n + '/6 ' + GUI.packed[guideLang]; };

// ---------- Read-aloud ----------
function ttsToggle(btn, key) {
  ttsSpeak(btn, ttsTexts[key], guideLang);
}

renderGuides();