function T(en, fil) { return { en: en, fil: fil }; }

var GUI = {
  heading:  T("Preparedness & Survival", "Paghahanda at Kaligtasan"),
  readAloud: T("Read aloud", "Basahin nang malakas"),
  step:     T("Step", "Hakbang"),
  packed:   T("Packed", "Naihanda"),
  chips: {
    all:      T("All Guides", "Lahat"),
    gobag:    T("🎒 Go-Bag Checklist", "🎒 Go-Bag"),
    surge:    T("🌊 Storm Surge", "🌊 Storm Surge"),
    firstaid: T("🩹 First Aid", "🩹 First Aid"),
    hotlines: T("📞 Hotlines", "📞 Mga Hotline")
  }
};

var GUIDES = {

  gobag: {
    title: T("Emergency Go-Bag Checklist", "Listahan ng mga Kailangang Ilagay sa Go-Bag para sa Emergency"),
    sub:   T("Essential items to pack before evacuating", "Mga mahahalagang bagay na dapat ihanda bago lumikas"),
    items: [
      T("4 Liters of clean drinking water (per person)", "4 litro ng malinis na inuming tubig (bawat tao)"),
      T("Ready-to-eat non-perishable canned food (3-day supply)", "Mga pagkaing de-lata na handa nang kainin at hindi madaling masira (sapat para sa 3 araw)"),
      T("Flashlight with extra fresh batteries", "Flashlight at ekstrang baterya"),
      T("Important legal IDs and documents sealed in waterproof pouch", "Mahahalagang ID at dokumentong nakalagay sa lalagyang hindi tinatablan ng tubig"),
      T("First aid kit with maintenance medications", "First aid kit at mga regular na iniinom na gamot"),
      T("Power bank, extra phone cables, and emergency whistle", "Power bank, ekstrang charging cable ng cellphone, at pito para sa emergency")
    ]
  },

  surge: {
    title: T("Storm Surge Protocol", "Mga Hakbang Kapag May Storm Surge"),
    intro: T(
      "A storm surge is sea water pushed onto land by a typhoon. It can reach far inland and arrive fast, so leave early.",
      "Ang storm surge ay tubig-dagat na itinutulak ng bagyo papunta sa kalupaan. Maaari itong umabot nang malayo sa baybayin at mabilis na dumating, kaya mahalagang lumikas nang maaga."
    ),
    subs: [
      {
        id: "before", icon: "📋",
        title: T("Before the storm", "Bago ang bagyo"),
        steps: [
          { h: T("Know your zone and your route", "Alamin ang inyong evacuation zone at ruta"),
            p: T("Check the Map tab for storm surge and flood zones. Know the nearest evacuation center and the safest way to walk there.",
                 "Tingnan ang Map tab para malaman kung aling mga lugar ang maaaring tamaan ng storm surge at baha. Alamin kung nasaan ang pinakamalapit na evacuation center at ang pinakaligtas na rutang papunta roon.") },
          { h: T("Follow official warnings", "Sundin ang opisyal na babala"),
            p: T("Listen to PAGASA, the MDRRMO and your barangay. When they order evacuation, go right away. Do not wait for the water to rise.",
                 "Makinig sa mga abiso ng PAGASA, MDRRMO, at inyong barangay. Kapag inatasan kayong lumikas, umalis agad. Huwag nang hintaying tumaas ang tubig.") },
          { h: T("Prepare your go-bag", "Ihanda ang go-bag"),
            p: T("Pack water, food, medicine, a flashlight, IDs, and a whistle. Keep documents in a waterproof pouch. Charge your phones and power banks.",
                 "Ilagay sa go-bag ang tubig, pagkain, gamot, flashlight, mga ID, at pito. Itago ang mga dokumento sa lalagyang hindi tinatablan ng tubig. I-charge ang mga cellphone at power bank.") },
          { h: T("Make a family plan", "Gumawa ng plano ng pamilya"),
            p: T("Choose a meeting place and one relative outside the area to contact. Write important phone numbers on paper.",
                 "Pumili ng tagpuan at isang kamag-anak na nasa labas ng lugar na maaaring kontakin. Isulat sa papel ang mahahalagang numero ng telepono.") },
          { h: T("Help those who need extra time", "Tulungan ang mga nangangailangan ng dagdag na oras"),
            p: T("Move children, the elderly, pregnant women, and people with disabilities early. Bring their medicines.",
                 "Palikasin nang maaga ang mga bata, matatanda, buntis, at may kapansanan. Dalhin ang kanilang mga gamot.") },
          { h: T("Shut off main utilities", "Patayin ang main na kuryente at gas"),
            p: T("Disconnect main electrical breakers and gas tanks to prevent electrocution or post-storm fires. Move valuables to a high place and tie boats down away from the shore.",
                 "Patayin ang pangunahing breaker ng kuryente at isara ang tangke ng gas upang maiwasan ang pagkakuryente o sunog pagkatapos ng bagyo. Ilipat sa mataas na lugar ang mahahalagang gamit at itali ang mga bangka nang malayo sa dalampasigan.") }
        ]
      },
      {
        id: "during", icon: "🌀",
        title: T("During the storm", "Habang may bagyo"),
        steps: [
          { h: T("Evacuate coastal areas immediately", "Lumikas agad mula sa baybayin"),
            p: T("If coastal water levels recede abnormally or storm surge alert Level 2 is issued, move to high ground right away. Do not stay in a house near the shore, even if it looks strong.",
                 "Kung biglang higit sa karaniwan ang pag-atras ng tubig sa baybayin, o kung may inilabas na Storm Surge Alert Level 2, agad na lumikas patungo sa mataas na lugar. Huwag manatili sa bahay na malapit sa dalampasigan, kahit mukhang matibay ito.") },
          { h: T("Seek high elevation structures", "Humanap ng mataas at matibay na gusali"),
            p: T("If trapped, move to the 2nd floor or higher floor of a reinforced concrete building like Southern Samar National Comprehensive HS. If the water keeps rising, go to the roof. Avoid closed attics where you can get stuck.",
                 "Kung hindi na makalabas, umakyat sa ikalawang palapag o mas mataas na palapag ng isang gusaling gawa sa reinforced concrete, tulad ng Southern Samar National Comprehensive HS. Kung patuloy na tumataas ang tubig, umakyat sa bubong. Iwasan ang mga saradong attic o silid sa itaas kung saan maaari kang ma-trap.") },
          { h: T("Stay out of moving water", "Huwag lumusong sa rumaragasang tubig"),
            p: T("Do not walk, swim or drive through floodwater. Just 15 centimeters of fast water can knock an adult down. Floodwater can hide holes, debris and live wires.",
                 "Huwag maglakad, lumangoy, o magmaneho sa baha. Kahit 15 sentimetro lamang ng mabilis na agos ay maaaring makapagpabagsak sa isang nasa hustong gulang. Maaaring may mga nakatagong butas, debris, at kable na may kuryente sa ilalim ng baha.") },
          { h: T("Do not go out in the calm “eye”", "Huwag lumabas kapag biglang kalmado (mata ng bagyo)"),
            p: T("If the wind suddenly stops, the eye of the typhoon may be passing over. Stay inside. Strong wind and surge can come back from the other direction.",
                 "Kapag biglang huminto ang hangin, maaaring dumaraan ang mata ng bagyo. Manatili sa loob. Maaaring bumalik ang malakas na hangin at storm surge mula sa kabilang direksiyon.") },
          { h: T("Stay in the safest part of the building", "Manatili sa pinakaligtas na bahagi ng gusali"),
            p: T("Stay away from windows and glass. Never go to the shore to watch the waves.",
                 "Lumayo sa bintana at salamin. Huwag pumunta sa dalampasigan para manood ng alon.") },
          { h: T("Save your phone battery", "Tipirin ang baterya ng cellphone"),
            p: T("Send text messages instead of calling. Texts go through weak signal more easily. Keep your phone off when you do not need it. Use a battery radio for updates.",
                 "Mag-text sa halip na tumawag. Mas madaling maipadala ang mga text kahit mahina ang signal. Patayin ang cellphone kapag hindi ito ginagamit. Gumamit ng radyong de-baterya para sa mga update.") }
        ]
      },
      {
        id: "after", icon: "🧹",
        title: T("After the storm", "Pagkatapos ng bagyo"),
        steps: [
          { h: T("Wait for the all-clear", "Hintayin ang abiso na ligtas na"),
            p: T("Do not go home until the MDRRMO says it is safe. Water can rise again and more rain may come.",
                 "Huwag umuwi hangga't hindi sinasabi ng MDRRMO na ligtas nang bumalik. Maaaring tumaas muli ang tubig at maaari pang umulan.") },
          { h: T("Stay out of floodwater", "Iwasan ang baha"),
            p: T("Floodwater carries germs, sharp objects and animals such as snakes. If you must wade, wear boots. Afterwards, wash with soap and clean water.",
                 "Maaaring may dalang mikrobyo, matutulis na bagay, at mga hayop tulad ng ahas ang baha. Kung kailangan mong lumusong, magsuot ng bota. Pagkatapos, maghugas gamit ang sabon at malinis na tubig.") },
          { h: T("Stay away from fallen wires", "Lumayo sa mga putol na kable"),
            p: T("Treat every fallen wire and every wet electrical post as live. Keep far away and report it to the MDRRMO or the electric cooperative.",
                 "Ituring na may kuryente ang bawat naputol o nalaglag na kable at bawat basang poste ng kuryente. Lumayo at ireport ito sa MDRRMO o sa electric cooperative.") },
          { h: T("Check the house before going in", "Suriin ang bahay bago pumasok"),
            p: T("Look for cracks, leaning walls and a sagging roof. If it looks unsafe, do not go in. Use a flashlight, not a candle, in case of gas leaks. Keep the gas tank closed until it is checked.",
                 "Suriin kung may mga bitak, nakahilig na dingding, o lumulundo na bubong. Kung mukhang hindi ligtas, huwag pumasok. Gumamit ng flashlight, hindi kandila, dahil maaaring may tagas ng gas. Panatilihing nakasara ang tangke ng gas hanggang masuri ito.") },
          { h: T("Clean up safely", "Maglinis nang ligtas"),
            p: T("Wear gloves, boots and long sleeves. Watch for nails, broken glass and GI sheets. Do not lift heavy debris alone.",
                 "Magsuot ng guwantes, bota, at mahabang manggas. Mag-ingat sa pako, basag na salamin at yero. Huwag magbuhat nang mag-isa ng mabibigat na kalat.") },
          { h: T("Make water and food safe", "Gawing ligtas ang tubig at pagkain"),
            p: T("Boil drinking water for at least 1 minute, or disinfect it (see First Aid). Throw away food that touched floodwater.",
                 "Pakuluan ang inuming tubig nang hindi bababa sa 1 minuto, o i-disinfect ito (tingnan ang First Aid). Itapon ang anumang pagkaing nadikitan o nabahiran ng tubig-baha.") },
          { h: T("Check on others and report", "Kumustahin ang iba at mag-ulat"),
            p: T("Check on neighbors, especially the elderly and children. Check in at your evacuation center in the Shelters tab so your family knows you are safe. Report damage and missing people to your barangay.",
                 "Kumustahin ang mga kapitbahay, lalo na ang matatanda at mga bata. Mag-check in sa evacuation center sa Shelters tab upang malaman ng pamilya ninyo na ligtas kayo. Ireport sa barangay ang mga pinsala at mga nawawalang tao.") }
        ]
      }
    ]
  },

  firstaid: {
    title: T("First Aid Fundamentals", "Mga Batayan ng First Aid"),
    intro: T(
      "These are the injuries and illnesses most common during and after typhoons. For serious cases, call the MDRRMO or 911. First aid does not replace a health worker. Get medical care as soon as it is safe to travel.",
      "Ito ang mga pinakakaraniwang pinsala at karamdaman na maaaring mangyari habang at pagkatapos ng bagyo. Para sa malulubhang kaso, tumawag sa MDRRMO o 911. Hindi kapalit ng tulong medikal ang first aid. Magpatingin sa lalong madaling panahon kapag ligtas nang bumiyahe."
    ),
    subs: [
      {
        id: "bleeding", icon: "🩸",
        title: T("Severe bleeding", "Matinding pagdurugo"),
        steps: [
          T("Apply firm, direct pressure on the wound using a clean cloth or bandage.",
            "Diinan nang maigi at direkta ang sugat gamit ang malinis na tela o benda."),
          T("Keep pressure steady for at least 10 minutes. Do not lift the cloth to check. If blood soaks through, add more cloth on top.",
            "Panatilihin ang pagdiin nang hindi bababa sa 10 minuto. Huwag itaas ang tela para silipin. Kung mapuno ng dugo ang tela, dagdagan ito ng panibagong tela sa ibabaw."),
          T("If there is no broken bone, raise the injured arm or leg higher than the heart.",
            "Kung walang baling buto, itaas ang nasugatang braso o binti nang mas mataas sa antas ng puso."),
          T("If bleeding does not stop, keep pressing and get help right away.",
            "Kung hindi tumitigil ang pagdurugo, ituloy ang pagdiin at humingi agad ng tulong.")
        ],
        warn: T("Get help right away if blood is spurting or soaking through many cloths, or the person is pale, dizzy, or confused.",
                "Humingi agad ng tulong kung bumubulwak ang dugo o nabasa na ang maraming tela, o kung maputla, nahihilo, o litong-lito ang tao.")
      },
      {
        id: "cuts", icon: "🩹",
        title: T("Cuts from glass, roofing sheets, and nails", "Hiwa at sugat mula sa salamin, yero, at pako"),
        cause: T("Common during clean-up, and when walking barefoot around debris.",
                 "Karaniwan habang naglilinis o kapag naglalakad nang walang sapin sa paligid ng mga kalat."),
        steps: [
          T("Stop the bleeding first with firm pressure.",
            "Itigil muna ang pagdurugo sa pamamagitan ng mahigpit na pagdiin."),
          T("Rinse the wound with clean running water for several minutes. Wash around it with soap. Gently remove dirt.",
            "Banlawan ang sugat ng malinis na tubig nang ilang minuto. Hugasan ng sabon ang paligid nito. Dahan-dahang alisin ang dumi."),
          T("Do not put oil, toothpaste, coffee or herbs on the wound.",
            "Huwag lagyan ng langis, toothpaste, kape, o halamang gamot ang sugat."),
          T("Cover with a clean bandage. Change it every day, or when it gets wet or dirty.",
            "Takpan ng malinis na benda. Palitan araw-araw, o kapag nabasa o narumihan."),
          T("See a health worker for a tetanus shot, especially for deep, dirty or rusty-nail wounds.",
            "Magpatingin sa health worker para sa anti-tetano, lalo na sa malalim, marumi, o sugat na nakuha sa kalawangin na pako.")
        ],
        warn: T("See a health worker soon if the wound is deep or has dirt you cannot remove, or if later there is spreading redness, swelling, pus or fever.",
                "Magpatingin agad sa health worker kung malalim ang sugat o may dumi na hindi maalis, o kung kalaunan ay may kumakalat na pamumula, pamamaga, nana, o lagnat.")
      },
      {
        id: "impaled", icon: "📌",
        title: T("Object stuck in the body", "May bagay na nakabaon sa katawan"),
        cause: T("For example a nail, a piece of wood or metal from flying debris.",
                 "Halimbawa ay pako, kahoy o bakal mula sa mga lumilipad na kalat."),
        steps: [
          T("Do not pull the object out. It may be blocking the bleeding.",
            "Huwag bunutin ang bagay. Maaaring ito ang pumipigil sa pagdurugo."),
          T("Press firmly on the skin around the object, not on the object.",
            "Diinan ang balat sa paligid ng bagay, hindi ang mismong bagay."),
          T("Pad both sides with thick cloth, and tape or tie it so the object cannot move.",
            "Lagyan ng makapal na tela ang magkabilang gilid, at tapalan o itali para hindi gumalaw ang bagay."),
          T("Keep the person still and get help right away.",
            "Panatilihing hindi gumagalaw ang tao at humingi agad ng tulong.")
        ]
      },
      {
        id: "fracture", icon: "🦴",
        title: T("Broken bones, sprains, and falls", "Baling buto, pilay, at pagkahulog"),
        cause: T("Caused by falling debris, slipping on wet ground or collapsed structures.",
                 "Dulot ng mga bumagsak na bagay, pagkadulas sa basang lupa o pagguho ng istruktura."),
        steps: [
          T("Do not move the injured part or try to straighten it.",
            "Huwag igalaw o subukang ituwid ang napinsalang bahagi."),
          T("Hold it still with a splint: a board, rolled newspaper, or sturdy stick, padded with cloth. Tie above and below the injury, not too tight.",
            "Pigilan itong gumalaw gamit ang pang-ipit (splint): tabla, nirolyong diyaryo, o matibay na patpat na may tela bilang unan. Itali sa itaas at ibaba ng pinsala, huwag masyadong mahigpit."),
          T("Put a cold, wet cloth over the area to ease swelling.",
            "Lagyan ng malamig at basang tela para mabawasan ang pamamaga."),
          T("Check the fingers or toes. If they turn pale, blue, cold, or numb; loosen the ties.",
            "Suriin ang mga daliri sa kamay o paa. Kung pumuti, umasul, lumamig, o namanhid; paluwagin ang tali."),
          T("Carry the person to a health facility. Do not let them walk on an injured leg.",
            "Dalhin ang tao sa pagamutan. Huwag palakarin kung sugatan ang binti.")
        ],
        warn: T("Emergency if a bone is sticking out of the skin. Cover the wound with a clean cloth and do not push the bone back.",
                "Emergency ito kung may butong lumalabas sa balat. Takpan ang sugat ng malinis na tela at huwag itulak pabalik ang buto.")
      },
      {
        id: "head", icon: "🧠",
        title: T("Head, neck, and back injuries", "Pinsala sa ulo, leeg, at likod"),
        cause: T("Caused by falling debris or collapsing roofs.",
                 "Dulot ng mga bumagsak na bagay o gumuhong bubong."),
        steps: [
          T("If you suspect a neck or back injury, do not move the person unless there is danger such as fire or rising water.",
            "Kung may hinala ng pinsala sa leeg o likod, huwag galawin ang tao maliban kung may panganib tulad ng sunog o tumataas na tubig."),
          T("Gently hold the head and neck still. Tell the person not to move.",
            "Dahan-dahang hawakan ang ulo at leeg para hindi gumalaw. Sabihan ang tao na huwag gumalaw."),
          T("If the scalp is bleeding, press gently around the wound with a clean cloth.",
            "Kung dumudugo ang anit, dahan-dahang diinan ang paligid ng sugat gamit ang malinis na tela."),
          T("Watch the person closely for the next 24 hours, even if they seem fine.",
            "Bantayan nang mabuti ang tao sa susunod na 24 oras, kahit mukha siyang maayos.")
        ],
        warn: T("Get help right away if the person passes out, vomits, is confused or very sleepy, has a seizure, or has blood or clear fluid coming from the nose or ears.",
                "Humingi agad ng tulong kung nawalan ng malay, nagsuka, litong-lito o sobrang antukin, nagkombulsyon, o may dugo o malinaw na likido na lumalabas sa ilong o tainga.")
      },
      {
        id: "trapped", icon: "🏚️",
        title: T("Trapped under debris", "Naipit sa ilalim ng mga guho"),
        steps: [
          T("Call for rescue and say the exact place. Shout or blow your whistle.",
            "Tumawag ng rescue at sabihin ang eksaktong lugar. Sumigaw o hipan ang pito."),
          T("Do not try to lift heavy debris alone. It can fall again and hurt you both.",
            "Huwag subukang buhatin mag-isa ang mabibigat na piraso ng gumuhong bagay. Maaari itong bumagsak ulit at kayong dalawa ang masaktan."),
          T("Stay with the person. Keep them calm, comfortable, warm, and awake. Keep talking to them.",
            "Samahan ang tao. Panatilihing kalmado, komportable, balot at mainit, at gising. Patuloy siyang kausapin."),
          T("Stop any bleeding you can reach. Give small sips of water only if they are awake.",
            "Pigilan ang pagdurugo na maaaring maaabot. Painumin ng kaunting tubig kung gising lamang."),
          T("Tell the rescuers how long the person was trapped.",
            "Sabihin sa mga rescuer kung gaano katagal naipit ang tao.")
        ],
        warn: T("A person trapped for a long time can become very sick after being freed. Take them to a hospital even if they seem fine.",
                "Ang taong matagal naipit ay maaaring magkasakit nang malubha pagkatapos mailabas. Dalhin sa ospital kahit mukhang maayos.")
      },
      {
        id: "drowning", icon: "🌊",
        title: T("Drowning", "Pagkalunod"),
        steps: [
          T("Reach or throw something that floats, like a rope, bottle or plank. Do not jump in unless you are trained.",
            "Mag-abot o maghagis ng bagay na nalutang tulad ng lubid, bote, o tabla. Huwag tumalon sa tubig maliban kung sanay."),
          T("Once the person is out, check if they are breathing.",
            "Kapag nakaahon na, tingnan kung humihinga."),
          T("If not breathing and you are trained: give 5 rescue breaths, then 30 chest pushes and 2 breaths. Repeat.",
            "Kung hindi humihinga at marunong kang magsagawa nito: magbigay ng 5 rescue breaths, pagkatapos ay 30 chest compressions at 2 rescue breaths. Ulitin."),
          T("If you are not trained: push hard and fast in the center of the chest, about 2 pushes a second, until help comes.",
            "Kung hindi ka sanay: diinan nang malakas at mabilis ang gitna ng dibdib, mga 2 diin kada segundo, hanggang dumating ang tulong."),
          T("If breathing: lay the person on their side, take off wet clothes and cover with something dry.",
            "Kung humihinga: ihiga ang tao nang nakatagilid, alisin ang basang damit, at ibalot ng tuyong damit o kumot.")
        ],
        warn: T("Everyone who swallowed or breathed in water must be checked by a health worker. Coughing, trouble breathing, or sleepiness hours later is an emergency.",
                "Ipasuri sa health worker ang sinumang nakalunok o nakalanghap ng tubig. Ang pag-ubo, hirap sa paghinga, o antok pagkalipas ng ilang oras ay emergency.")
      },
      {
        id: "shock", icon: "⚡",
        title: T("Electric shock", "Pagkakuryente"),
        cause: T("From fallen wires, wet electrical posts, or flooded outlets.",
                 "Mula sa nalaglag na kable, basang poste ng kuryente, o binahang saksakan."),
        steps: [
          T("Do not touch the person or the wire. Water makes it more dangerous. Keep everyone away.",
            "Huwag hawakan ang tao o ang kable. Mas mapanganib kapag basa. Palayuin ang lahat."),
          T("Turn off the main power only if you can reach it safely. Otherwise call the MDRRMO or the electric cooperative.",
            "Patayin ang main na kuryente kung ligtas itong maaabot. Kung hindi, tumawag sa MDRRMO o sa electric cooperative."),
          T("Only when the power is off: check breathing and give CPR if needed.",
            "Kapag patay na ang kuryente: tingnan ang paghinga at magbigay ng CPR kung kailangan."),
          T("Cover burns with a clean, dry cloth.",
            "Takpan ng malinis at tuyong tela ang mga paso.")
        ],
        warn: T("Everyone who was shocked needs a health check, even if they feel fine. A shock can affect the heart.",
                "Dapat ipasuri ang sinumang nakuryente, kahit maayos ang pakiramdam. Maaaring maapektuhan ang puso.")
      },
      {
        id: "burns", icon: "🔥",
        title: T("Burns", "Paso"),
        cause: T("From candles, kerosene lamps, gas stoves, generators, and hot water.",
                 "Mula sa kandila, gasera, kalan na gas, generator, at mainit na tubig."),
        steps: [
          T("Cool the burn under clean running water for 20 minutes.",
            "Palamigin ang paso gamit ang malinis na tubig sa loob ng 20 minuto."),
          T("Take off rings and tight clothes near the burn before it swells. Do not pull off cloth that is stuck.",
            "Tanggalin ang singsing at masisikip na damit malapit sa paso bago ito mamaga. Huwag hilahin ang telang nakadikit."),
          T("Cover loosely with a clean cloth or plastic wrap.",
            "Takpan nang maluwag na malinis na tela o plastic wrap."),
          T("Do not use ice, toothpaste, oil or butter. Do not pop blisters.",
            "Huwag gumamit ng yelo, toothpaste, langis o mantikilya. Huwag putukin ang mga paltos.")
        ],
        warn: T("Get help right away if the burn is large, on the face, hands or private parts, or the skin looks white or black.",
                "Humingi agad ng tulong kung malaki ang paso, nasa mukha, kamay o pribadong bahagi, o kapag pumuti o umitim ang balat.")
      },
      {
        id: "bites", icon: "🐍",
        title: T("Snake and animal bites", "Kagat ng ahas at hayop"),
        cause: T("Snakes and other animals look for dry ground and can end up in homes after floods.",
                 "Naghahanap ng tuyong lugar ang mga ahas at iba pang hayop, at maaaring mapunta sa mga bahay pagkatapos ng baha."),
        steps: [
          T("Move away from the animal. Keep the person calm and still.",
            "Lumayo sa hayop. Panatilihing kalmado at hindi gumagalaw ang tao."),
          T("Keep the bitten arm or leg still, at about heart level. Take off rings and tight items.",
            "Panatilihing hindi gumagalaw ang nakagat na braso o binti, kasing-taas ng puso. Tanggalin ang singsing at masisikip na bagay."),
          T("Do not cut, suck, burn, or tie the bite tightly. Do not use ice or herbs.",
            "Huwag hiwain, sipsipin, sunugin, o itali nang mahigpit ang kagat. Huwag gumamit ng yelo o halamang gamot."),
          T("Do not try to catch the snake. Remember what it looked like.",
            "Huwag hulihin ang ahas. Tandaan ang itsura nito."),
          T("Go to the hospital right away.",
            "Pumunta agad sa ospital."),
          T("For dog or cat bites: wash with soap and running water for at least 15 minutes, then go to an animal bite center for rabies shots.",
            "Sa kagat ng aso o pusa: hugasan ng sabon at umaagos na tubig nang hindi bababa sa 15 minuto, saka pumunta sa animal bite center para sa bakuna kontra rabies.")
        ]
      },
      {
        id: "eye", icon: "👁️",
        title: T("Eye injuries", "Pinsala sa mata"),
        cause: T("From flying dust, sand, and small debris in strong wind.",
                 "Mula sa lumilipad na alikabok, buhangin, at maliliit na bagay dahil sa malakas na hangin."),
        steps: [
          T("Do not rub the eye.",
            "Huwag kuskusin ang mata."),
          T("For dust or small bits, rinse gently with clean water for several minutes.",
            "Kung alikabok o maliliit na piraso, banlawan nang dahan-dahan gamit ang malinis na tubig nang ilang minuto."),
          T("If something is stuck in the eye, do not remove it. Cover the eye with a clean cloth without pressing on it.",
            "Kung may nakabaon sa mata, huwag tanggalin. Takpan ang mata ng malinis na tela nang hindi dinidiinan."),
          T("Get to a health worker.",
            "Magpatingin sa health worker.")
        ]
      },
      {
        id: "cold", icon: "🥶",
        title: T("Cold and wet exposure", "Ginaw at pagkabasa"),
        cause: T("From staying wet in wind and rain for a long time. Signs: shivering, cold skin, weakness, confusion.",
                 "Dahil sa matagal na pagkabasa sa hangin at ulan. Mga palatandaan: panginginig, malamig na balat, panghihina, pagkalito."),
        steps: [
          T("Move to shelter, out of the wind and rain.",
            "Pumunta sa masisilungan, malayo sa hangin at ulan."),
          T("Take off wet clothes. Dry the person and wrap in dry clothes or a blanket. Cover the head.",
            "Hubarin ang basang damit. Punasan at patuyuin ang tao, at ibalot ng tuyong damit o kumot. Takpan ang ulo."),
          T("If fully awake, give warm sweet drinks. No alcohol.",
            "Kung gising, painumin ng mainit at matamis na inumin. Huwag bigyan ng alak."),
          T("Do not rub the skin. Warm the chest and body first, not the arms and legs.",
            "Huwag kuskusin ang balat. Painitin muna ang dibdib at katawan, hindi ang mga braso at binti.")
        ],
        warn: T("Get help right away if the person is very sleepy, stops shivering, is confused, or breathes weakly.",
                "Humingi agad ng tulong kung sobrang antukin ang tao, tumigil sa panginginig, litong-lito, o mahina ang paghinga.")
      },
      {
        id: "diarrhea", icon: "💧",
        title: T("Diarrhea and dehydration", "Pagtatae at dehydration"),
        cause: T("From unsafe water and spoiled food after floods.",
                 "Mula sa maruming tubig at sirang pagkain pagkatapos ng baha."),
        steps: [
          T("Give small sips often. Use oral rehydration salts (ORS) if available.",
            "Painumin ng kaunti at pero madalas. Gumamit ng oral rehydration salts (ORS) kung mayroon."),
          T("Homemade rehydration drink: mix 1 liter of clean water with 6 teaspoons of sugar and half a teaspoon of salt.",
            "Inuming maaaring gawin sa bahay: ihalo sa 1 litro ng malinis na tubig ang 6 na kutsaritang asukal at kalahating kutsaritang asin."),
          T("Keep feeding the person. Keep breastfeeding babies.",
            "Patuloy na pakainin ang tao. Ituloy ang pagpapasuso sa sanggol.")
        ],
        warn: T("Go to a health worker right away if there is blood in the stool, high fever, sunken eyes, very little urine, or the person cannot drink. Babies, young children and the elderly need help early.",
                "Pumunta agad sa health worker kung may dugo sa dumi, mataas na lagnat, lubog na mata, kaunting ihi, o hindi makainom ang tao. Kailangan ng maagang tulong ang mga sanggol, bata at matatanda.")
      },
      {
        id: "water", icon: "🚰",
        title: T("Making drinking water safe", "Paggawa ng ligtas na inuming tubig"),
        steps: [
          T("Best: boil the water at a rolling boil for at least 1 minute.",
            "Pinakamainam: pakuluan ang tubig nang hindi bababa sa 1 minuto."),
          T("If boiling is impossible, add 2 drops of unscented household bleach per 1 liter of water and let sit for 30 minutes before drinking.",
            "Kung hindi makapagpakulo, magdagdag ng 2 patak ng bleach na walang pabango sa bawat 1 litro ng tubig at hayaang nakababad nang 30 minuto bago inumin."),
          T("If the water is cloudy, let it settle, then pour it through a clean cloth first.",
            "Kung malabo ang tubig, hayaan munang lumubog ang mga dumi, at salain ito gamit ang malinis na tela bago i-disinfect.")
        ]
      },
      {
        id: "lepto", icon: "🌡️",
        title: T("Fever after walking in floodwater (leptospirosis)", "Lagnat pagkatapos lumusong sa baha (leptospirosis)"),
        cause: T("Germs from animal urine in floodwater can enter through cuts or wet skin. Signs can appear 2 to 30 days later: fever, headache, muscle or calf pain, red eyes, yellow skin or eyes.",
                 "Ang mikrobyo mula sa ihi ng hayop sa baha ay maaaring pumasok sa sugat o basang balat. Maaaring lumitaw ang mga palatandaan 2 hanggang 30 araw pagkatapos: lagnat, sakit ng ulo, pananakit ng kalamnan o binti, pulang mata, madilaw na balat o mata."),
        steps: [
          T("If you waded in floodwater, go to the health center as soon as you can, ideally within 3 days. They may give preventive medicine.",
            "Kung lumusong ka sa baha, pumunta sa health center sa lalong madaling panahon, mas mainam kung sa loob ng 3 araw. Maaaring bigyan ka roon ng gamot bilang pag-iwas sa leptospirosis."),
          T("Wash well with soap and clean water after wading. Clean any cut and cover it.",
            "Maghugas nang mabuti ng sabon at malinis na tubig pagkatapos lumusong. Linisin at takpan ang anumang sugat."),
          T("Do not wait. Go to the health center or hospital if fever or other signs appear.",
            "Huwag maghintay. Pumunta sa health center o ospital kung may lagnat o iba pang palatandaan.")
        ]
      }
    ]
  },

  hotlines: {
    title: T("Balangiga LGU Emergency Hotlines", "Mga Emergency Hotline ng Balangiga LGU"),
    items: [
      { icon: "phone-call", name: T("MDRRMO Hotline", "MDRRMO Hotline"), tel: "09170000000", shown: "0917-000-0000" },
      { icon: "shield",     name: T("Municipal Police Station", "Himpilan ng Pulisya ng Munisipyo"), tel: "09180000000", shown: "0918-000-0000" },
      { icon: "flame",      name: T("BFP Fire Station", "Istasyon ng Bumbero (BFP)"), tel: "09200000000", shown: "0920-000-0000" }
    ]
  }
};