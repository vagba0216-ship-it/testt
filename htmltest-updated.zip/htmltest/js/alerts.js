function updateBarangayAlert() {
  const bgy = document.getElementById('barangaySelect').value;

  document.getElementById('alertContent').innerHTML = `
    <h4>
      <i data-lucide="cloud-lightning"
        style="width:18px;height:18px;"></i>
      Heavy Rainfall Alert
    </h4>

    <p>
      Monitoring hazard conditions for
      <b>Barangay ${bgy}</b>.
      Residents should monitor evacuation instructions
      and avoid identified hazard zones.
    </p>
  `;

  document.getElementById('mapHazardText').innerText =
    `Hazard monitoring active for Barangay ${bgy}.`;

  lucide.createIcons();

  if (map) {
    document.querySelector('[onclick*="map-tab"]').click();

    setTimeout(() => {
      map.invalidateSize();
    }, 200);
  }
}
