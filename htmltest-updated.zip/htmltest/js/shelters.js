// Shelters tab: capacity list and check-in
// --- State Management ---
let sheltersData = [
  { id: 'muni', name: 'Balangiga Municipal Hall', location: 'Poblacion', current: 85, max: 100 },
  { id: 'ssnchs', name: 'Southern Samar National Comp. HS', location: 'San Fernando', current: 120, max: 500 },
  { id: 'bces', name: 'Balangiga Central Elem. School', location: 'Poblacion', current: 249, max: 250 }
];

let userCheckedInId = localStorage.getItem('userCheckedInId') || null;

// --- Shelter Check-In System ---
function renderShelters() {
  const container = document.getElementById('sheltersList');
  container.innerHTML = '';

  const userStatusTitle = document.getElementById('statusTitle');
  const userStatusSub = document.getElementById('statusSub');

  let currentCheckedShelter = sheltersData.find(s => s.id === userCheckedInId);

  if (currentCheckedShelter) {
    userStatusTitle.innerHTML = `<span style="color:var(--success)">Checked In: ${currentCheckedShelter.name}</span>`;
    userStatusSub.innerText = `Occupancy count updated. Tap "Check Out" if you leave.`;
  } else {
    userStatusTitle.innerText = "Not Checked In";
    userStatusSub.innerText = "Tap 'Check In' below when you reach safety.";
  }

  sheltersData.forEach(shelter => {
    const pct = Math.round((shelter.current / shelter.max) * 100);
    
    let color = 'var(--success)';
    let statusText = `${pct}% Occupied`;
    if (pct >= 80 && pct < 100) { color = 'var(--warning)'; }
    else if (pct >= 100) { color = 'var(--primary)'; statusText = 'At Max Capacity'; }

    const isUserHere = shelter.id === userCheckedInId;

    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-header">
        <div>
          <div class="card-title">${shelter.name}</div>
          <p style="font-size: 0.8rem; color: var(--text-muted);">${shelter.location} • Capacity: ${shelter.current} / ${shelter.max}</p>
        </div>
        <button class="btn-checkin ${isUserHere ? 'active' : ''}" onclick="toggleCheckIn('${shelter.id}')">
          <i data-lucide="${isUserHere ? 'user-check' : 'user-plus'}" style="width:14px; height:14px;"></i>
          ${isUserHere ? 'Checked In' : 'Check In'}
        </button>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill" style="width: ${Math.min(pct, 100)}%; background: ${color};"></div>
      </div>
    `;
    container.appendChild(card);
  });

  lucide.createIcons();
}

function toggleCheckIn(shelterId) {
  if (userCheckedInId === shelterId) {
    // User is checking out of current shelter
    let target = sheltersData.find(s => s.id === shelterId);
    if (target && target.current > 0) target.current--;
    userCheckedInId = null;
  } else {
    // Check out of previous shelter if checked in
    if (userCheckedInId) {
      let prev = sheltersData.find(s => s.id === userCheckedInId);
      if (prev && prev.current > 0) prev.current--;
    }
    // Check in to new shelter
    let target = sheltersData.find(s => s.id === shelterId);
    if (target) {

      if (target.current >= target.max) {
        alert(
          "This evacuation center is currently at full capacity. " +
          "Please proceed to another available evacuation center."
        );

        renderShelters();
        return;
      }

      target.current++;
      userCheckedInId = shelterId;
    }
  }

  localStorage.setItem('userCheckedInId', userCheckedInId || '');
  renderShelters();
}
