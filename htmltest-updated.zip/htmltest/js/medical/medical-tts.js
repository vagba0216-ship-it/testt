var MED_SPEECH = {
  en: {
    title: 'Medical card.',
    name: 'Name',
    age: 'Age',
    years: 'years old',
    barangay: 'Barangay',
    blood: 'Blood type',
    positive: 'positive',
    negative: 'negative',
    contact: 'Emergency contact',
    number: 'Number',
    fields: {
      allergies:  'Allergies',
      conditions: 'Diseases or medical conditions',
      disorders:  'Disorders',
      disability: 'Disability or special needs',
      medicines:  'Regular medicines',
      marks:      'Identifying marks'
    }
  },
  fil: {
    title: 'Medical card.',
    name: 'Pangalan',
    age: 'Edad',
    years: 'taong gulang',
    barangay: 'Barangay',
    blood: 'Uri ng dugo',
    positive: 'positibo',
    negative: 'negatibo',
    contact: 'Taong tatawagan sa oras ng emergency',
    number: 'Numero',
    fields: {
      allergies:  'Mga allergy',
      conditions: 'Mga sakit o kondisyong medikal',
      disorders:  'Mga disorder',
      disability: 'Kapansanan o espesyal na pangangailangan',
      medicines:  'Mga regular na gamot',
      marks:      'Mga palatandaan sa katawan, tulad ng tattoo o peklat'
    }
  }
};

function medSpeakBlood(b, S) {
  var m = /^(A|B|AB|O)([+-])$/.exec(b || '');
  if (!m) return '';
  return m[1].split('').join(' ') + ' ' + (m[2] === '+' ? S.positive : S.negative);
}

function medSpeakDigits(n) {
  var d = String(n || '').replace(/\D/g, '');
  if (!d) return '';
  var groups = [];
  for (var i = 0; i < d.length; i += 4) groups.push(d.slice(i, i + 4).split('').join(' '));
  return groups.join(', ');
}

function medSpeechText(c, lang) {
  var S = MED_SPEECH[lang] || MED_SPEECH.en;
  var parts = [S.title, S.name + ': ' + c.name + '.'];
  if (c.age) parts.push(S.age + ': ' + c.age + ' ' + S.years + '.');
  if (c.barangay) parts.push(S.barangay + ': ' + c.barangay + '.');
  var blood = medSpeakBlood(c.blood, S);
  if (blood) parts.push(S.blood + ': ' + blood + '.');
  MED_FIELDS.forEach(function (f) {
    var v = c[f.key];
    if (v) parts.push(S.fields[f.key] + ': ' + v.replace(/\s*\n\s*/g, ', ').replace(/[.!?:]+\s*$/, '') + '.');
  });
  if (c.ecName || c.ecPhone) {
    var who = c.ecName ? c.ecName + '.' : '';
    var num = medSpeakDigits(c.ecPhone);
    parts.push(S.contact + ': ' + who + (num ? ' ' + S.number + ': ' + num + '.' : ''));
  }
  return parts.join(' ');
}

function medSpeak(btn, lang) {
  var c = medLoad();
  if (!c) return;
  if (!TTS_OK) {
    showTtsNote("This browser cannot read aloud. Try Google Chrome on your phone.\nHindi kaya ng browser na ito ang text-to-speech. Subukan ang Google Chrome sa cellphone.");
    return;
  }
  ttsSpeak(btn, medSpeechText(c, lang), lang);
}

function medSpeakHTML() {
  var icons = '<i data-lucide="volume-2" class="ico-play" style="width:16px;height:16px;"></i>' +
              '<i data-lucide="square" class="ico-stop" style="width:16px;height:16px;"></i>';
  return '<div class="med-speak-box">' +
           '<div class="med-speak-title">🔊 Read card aloud / Basahin nang malakas</div>' +
           '<div class="med-actions-row">' +
             '<button type="button" class="btn-secondary med-speak" onclick="medSpeak(this,\'en\')">' + icons + ' English</button>' +
             '<button type="button" class="btn-secondary med-speak" onclick="medSpeak(this,\'fil\')">' + icons + ' Tagalog</button>' +
           '</div>' +
         '</div>';
}