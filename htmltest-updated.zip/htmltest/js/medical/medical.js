var MED_KEY = 'medCard';
var MED_SMS_NUMBER = '09170000000';

var MED_FIELDS = [
  { key: 'allergies',  label: 'Allergies',                 icon: '⚠️', alert: true },
  { key: 'conditions', label: 'Diseases / medical conditions', icon: '🩺' },
  { key: 'disorders',  label: 'Disorders',                 icon: '🧠' },
  { key: 'disability', label: 'Disability / special needs', icon: '♿' },
  { key: 'medicines',  label: 'Regular medicines',         icon: '💊' },
  { key: 'marks',      label: 'Identifying marks',         icon: '🔍', optional: true }   // optional: hidden on the card when empty
];

function medEsc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function medLoad() {
  try { return JSON.parse(localStorage.getItem(MED_KEY) || 'null'); } catch (e) { return null; }
}
function medStore(card) {
  try { localStorage.setItem(MED_KEY, JSON.stringify(card)); return true; } catch (e) { return false; }
}

function medField(id, label, controlHTML, hint) {
  return '<div class="med-field"><label class="med-label" for="' + id + '">' + label + '</label>' + controlHTML +
         (hint ? '<div class="med-hint">' + hint + '</div>' : '') + '</div>';
}

function medTextarea(id, ph) {
  return '<textarea id="' + id + '" class="textarea-control" rows="2" maxlength="300" placeholder="' + ph + '"></textarea>';
}

// ---------- Form ----------
function medShowForm() {
  stopSpeech();
  var saved = medLoad() || {};
  var root = document.getElementById('medRoot');

  var brgyOpts = '<option value="">Select barangay</option>';
  var src = document.getElementById('barangaySelect');
  if (src) [].forEach.call(src.options, function (o) { brgyOpts += '<option value="' + medEsc(o.value) + '">' + medEsc(o.value) + '</option>'; });

  var blood = ['Unknown', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    .map(function (b) { return '<option value="' + b + '">' + b + '</option>'; }).join('');

  root.innerHTML =
    '<h3 style="font-size:1.1rem; font-weight:700;">Personal Medical Card</h3>' +
    '<p class="med-sub">Fill this in before a storm. If you are hurt or cannot speak, responders can read it right away. ' +
      'Only write what you are comfortable sharing. Do not write ID, bank or card numbers.</p>' +
    '<div class="card">' +
      medField('med_name', 'Full name *', '<input id="med_name" class="select-control" type="text" maxlength="80" autocomplete="off">') +
      '<div class="med-two">' +
        medField('med_age', 'Age', '<input id="med_age" class="select-control" type="number" min="0" max="120" inputmode="numeric">') +
        medField('med_blood', 'Blood type', '<select id="med_blood" class="select-control">' + blood + '</select>') +
      '</div>' +
      medField('med_brgy', 'Barangay', '<select id="med_brgy" class="select-control">' + brgyOpts + '</select>') +
      medField('med_allergies', 'Allergies', medTextarea('med_allergies', 'e.g. penicillin, shrimp, bee stings'), 'Medicines, food, insects, latex...') +
      medField('med_conditions', 'Diseases / medical conditions', medTextarea('med_conditions', 'e.g. diabetes, asthma, high blood pressure, heart disease')) +
      medField('med_disorders', 'Disorders', medTextarea('med_disorders', 'e.g. epilepsy, autism, anxiety disorder'), 'Mental, neurological or developmental') +
      medField('med_disability', 'Disability / special needs', medTextarea('med_disability', 'e.g. uses a wheelchair, hard of hearing, needs help evacuating')) +
      medField('med_medicines', 'Regular medicines', medTextarea('med_medicines', 'e.g. insulin, maintenance for hypertension')) +
      medField('med_marks', 'Identifying marks <span class="med-optional">(optional)</span>',
               medTextarea('med_marks', 'e.g. rose tattoo on left forearm, scar on right knee, mole on neck'),
               'Tattoos, scars, birthmarks, moles... helps responders identify you.') +
      '<div class="med-two">' +
        medField('med_ecname', 'Emergency contact', '<input id="med_ecname" class="select-control" type="text" maxlength="80" placeholder="Name" autocomplete="off">') +
        medField('med_ecphone', 'Contact number', '<input id="med_ecphone" class="select-control" type="tel" maxlength="20" placeholder="09xx xxx xxxx" inputmode="tel">') +
      '</div>' +
      '<div class="med-error" id="medError"></div>' +
      '<div class="med-actions" style="margin-top:4px;">' +
        '<button type="button" class="btn-emergency" onclick="medSaveForm()"><i data-lucide="save" style="width:16px;height:16px;"></i> Save card</button>' +
        (medLoad() ? '<button type="button" class="btn-secondary" onclick="medShowCard()">Cancel</button>' : '') +
      '</div>' +
    '</div>';

  var map = { med_name: 'name', med_age: 'age', med_blood: 'blood', med_brgy: 'barangay', med_allergies: 'allergies',
              med_conditions: 'conditions', med_disorders: 'disorders', med_disability: 'disability',
              med_medicines: 'medicines', med_marks: 'marks', med_ecname: 'ecName', med_ecphone: 'ecPhone' };
  Object.keys(map).forEach(function (id) {
    var el = document.getElementById(id), v = saved[map[id]];
    if (el && v != null && v !== '') el.value = v;
  });
  if (window.lucide) lucide.createIcons();
}

function medSaveForm() {
  var g = function (id) { return (document.getElementById(id).value || '').trim(); };
  var err = document.getElementById('medError');
  if (!g('med_name')) {
    err.textContent = 'Please enter your name.';
    err.style.display = 'block';
    document.getElementById('med_name').focus();
    return;
  }
  var card = {
    name: g('med_name'), age: g('med_age'), blood: g('med_blood'), barangay: g('med_brgy'),
    allergies: g('med_allergies'), conditions: g('med_conditions'), disorders: g('med_disorders'),
    disability: g('med_disability'), medicines: g('med_medicines'), marks: g('med_marks'),
    ecName: g('med_ecname'), ecPhone: g('med_ecphone'),
    updated: new Date().toISOString()
  };
  if (!medStore(card)) {
    err.textContent = 'Could not save on this phone (browser storage is blocked). You can still use Share to send it.';
    err.style.display = 'block';
    return;
  }
  medShowCard();
}

// ---------- Card view ----------
function medSummaryText(c) {
  var lines = ['MEDICAL CARD - Balangiga ResQ', 'Name: ' + c.name];
  if (c.age) lines.push('Age: ' + c.age);
  if (c.barangay) lines.push('Barangay: ' + c.barangay);
  if (c.blood && c.blood !== 'Unknown') lines.push('Blood type: ' + c.blood);
  MED_FIELDS.forEach(function (f) { if (c[f.key]) lines.push(f.label + ': ' + c[f.key].replace(/\s*\n\s*/g, ', ')); });
  if (c.ecName || c.ecPhone) lines.push('Emergency contact: ' + [c.ecName, c.ecPhone].filter(Boolean).join(' '));
  return lines.join('\n');
}

function medShowCard() {
  var c = medLoad();
  if (!c) { medShowForm(); return; }
  var root = document.getElementById('medRoot');

  var meta = [c.age ? c.age + ' years old' : '', c.barangay ? 'Brgy. ' + c.barangay : ''].filter(Boolean).join(' • ');
  var rows = '';
  MED_FIELDS.forEach(function (f) {
    var v = c[f.key];
    if (f.optional && !v) return;
    rows += '<div class="med-row' + (f.alert && v ? ' alert' : '') + '"><h6>' + f.icon + ' ' + f.label + '</h6>' +
            (v ? '<p>' + medEsc(v) + '</p>' : '<p class="empty">Not listed</p>') + '</div>';
  });

  var contact = '<p class="empty">Not listed</p>';
  if (c.ecName || c.ecPhone) {
    var tel = (c.ecPhone || '').replace(/[^\d+]/g, '');
    contact = '<p>' + medEsc(c.ecName || '') + (c.ecName && c.ecPhone ? ' - ' : '') + medEsc(c.ecPhone || '') + '</p>' +
              (tel ? '<a class="btn-secondary med-call" href="tel:' + tel + '"><i data-lucide="phone-call" style="width:16px;height:16px;"></i> Call</a>' : '');
  }

  root.innerHTML =
    '<div class="med-card">' +
      '<div class="med-card-head"><span>MEDICAL CARD</span><span>Balangiga ResQ</span></div>' +
      '<div class="med-card-top">' +
        '<div><div class="med-name">' + medEsc(c.name) + '</div>' + (meta ? '<div class="med-meta">' + medEsc(meta) + '</div>' : '') + '</div>' +
        '<div class="med-blood"><small>BLOOD</small><strong>' + medEsc(c.blood && c.blood !== 'Unknown' ? c.blood : '?') + '</strong></div>' +
      '</div>' +
      rows +
      '<div class="med-row"><h6>📞 Emergency contact</h6>' + contact + '</div>' +
    '</div>' +
    medSpeakHTML() +
    '<div class="med-actions">' +
      '<button type="button" class="btn-emergency" onclick="medSendSms()"><i data-lucide="message-square" style="width:16px;height:16px;"></i> Send to MDRRMO by SMS</button>' +
      '<div class="med-actions-row">' +
        '<button type="button" class="btn-secondary" onclick="medShare()"><i data-lucide="share-2" style="width:16px;height:16px;"></i> Share</button>' +
        '<button type="button" class="btn-secondary" onclick="medShowForm()"><i data-lucide="pencil" style="width:16px;height:16px;"></i> Edit</button>' +
      '</div>' +
      '<button type="button" class="med-link-danger" onclick="medDelete()">Delete my card from this phone</button>' +
    '</div>' +
    '<div class="med-note">Your card is saved only on this phone. It is shared only when you tap Send or Share, and by sending it you allow the MDRRMO and responders to read it. ' +
      'If you are rescued, show this screen to the responder.</div>';

  if (window.lucide) lucide.createIcons();
}

// ---------- Sharing ----------
function medSmsLink() {
  var c = medLoad(); if (!c) return '';
  var sep = /iPhone|iPad|iPod/i.test(navigator.userAgent) ? '&' : '?';
  return 'sms:' + MED_SMS_NUMBER + sep + 'body=' + encodeURIComponent(medSummaryText(c));
}

function medSendSms() {
  var link = medSmsLink();
  if (link) window.location.href = link;
}

function medShare() {
  var c = medLoad(); if (!c) return;
  var text = medSummaryText(c);
  if (navigator.share) {
    navigator.share({ title: 'Medical Card - ' + c.name, text: text }).catch(function () {});
  } else if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () { alert('Medical card copied. You can paste it into a message.'); },
                                             function () { alert(text); });
  } else {
    alert(text);
  }
}

function medDelete() {
  if (!confirm('Delete your medical card from this phone?')) return;
  try { localStorage.removeItem(MED_KEY); } catch (e) {}
  medShowForm();
}

medLoad() ? medShowCard() : medShowForm();
