lucide.createIcons();

// --- Navigation ---
function showTab(tabId, btn) {
  if (typeof stopSpeech === 'function') stopSpeech();
  document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  
  document.getElementById(tabId).classList.add('active');
  btn.classList.add('active');

  if (tabId === 'map-tab' && map) {
    setTimeout(() => map.invalidateSize(), 100);
  }
}
