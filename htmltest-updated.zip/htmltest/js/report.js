function submitReport() {
  const val = document.getElementById('reportText').value;
  if (val.trim() === "") return alert("Please enter report details first.");
  alert("Report successfully saved to local queue!");
  document.getElementById('reportText').value = "";
}
