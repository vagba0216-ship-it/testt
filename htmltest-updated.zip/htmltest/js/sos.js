// SOS, opt-in toggle, trigger, shake detection
// --- SOS Functions ---
function toggleSOS(enabled) {
  document.getElementById('sosBtn').disabled = !enabled;
}

function triggerSOS(cause) {
  navigator.geolocation.getCurrentPosition(
    (pos) => alert(`${cause}\n\nGPS Coordinates Captured:\nLat: ${pos.coords.latitude}\nLong: ${pos.coords.longitude}\n\nBroadcasted to LGU emergency network!`),
    () => alert(`${cause}\n\nCoordinates fallback: Lat: 11.1105, Long: 125.3833\n\nBroadcasted to LGU emergency network!`)
  );
}

// Accelerometer Shake Detection
if (window.DeviceMotionEvent) {
  window.addEventListener('devicemotion', (e) => {
    let acc = e.accelerationIncludingGravity;
    if (acc && (Math.abs(acc.x) > 22 || Math.abs(acc.y) > 22)) {
      if (document.getElementById('sosToggle').checked) {
        triggerSOS("Backup Shake Sensor Triggered!");
      }
    }
  });
}
