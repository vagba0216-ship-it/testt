var ttsState = { token: 0 };
var TTS_OK = ('speechSynthesis' in window) && ('SpeechSynthesisUtterance' in window);

var TTS_NO_FIL_VOICE =
  "No Filipino voice was found on this phone. Install one in your phone's Text-to-speech settings. Using the default voice for now.\n" +
  "Walang Filipino na boses sa cellphone na ito. Mag-install nito sa Text-to-speech settings ng cellphone. Gagamitin muna ang default na boses.";

function clearSpeakingUI() {
  document.querySelectorAll('.tts-btn.speaking, .med-speak.speaking').forEach(function (b) { b.classList.remove('speaking'); });
}

function stopSpeech() {
  ttsState.token++;
  if (TTS_OK) { try { speechSynthesis.cancel(); } catch (e) {} }
  clearSpeakingUI();
}

function pickVoice(lang) {
  var voices = (TTS_OK && speechSynthesis.getVoices()) || [];
  var norm = function (v) { return (v.lang || '').toLowerCase().replace('_', '-'); };
  var found = null;
  if (lang === 'fil') {
    found = voices.filter(function (v) { var l = norm(v); return l.indexOf('fil') === 0 || l.indexOf('tl') === 0; })[0] || null;
  } else {
    ['en-ph', 'en-us', 'en-gb'].some(function (p) {
      found = voices.filter(function (v) { return norm(v) === p; })[0] || null;
      return !!found;
    });
    if (!found) found = voices.filter(function (v) { return norm(v).indexOf('en') === 0; })[0] || null;
  }
  return { voice: found, hasVoices: voices.length > 0 };
}

function showTtsNote(msg) {
  var n = document.getElementById('ttsNote');
  if (!n) { n = document.createElement('div'); n.id = 'ttsNote'; n.className = 'tts-note'; document.body.appendChild(n); }
  n.textContent = msg;
  n.style.display = 'block';
  clearTimeout(showTtsNote._t);
  showTtsNote._t = setTimeout(function () { n.style.display = 'none'; }, 7000);
}

function ttsSpeak(btn, text, lang) {
  if (!TTS_OK || !text) return;
  if (btn && btn.classList.contains('speaking')) { stopSpeech(); return; }
  stopSpeech();

  var chunks = (text.match(/[^.!?:]+[.!?:]*/g) || [text]).map(function (s) { return s.trim(); }).filter(Boolean);

  var token = ++ttsState.token;
  if (btn) btn.classList.add('speaking');

  var pv = pickVoice(lang);
  if (lang === 'fil' && pv.hasVoices && !pv.voice) showTtsNote(TTS_NO_FIL_VOICE);

  setTimeout(function () {
    if (token !== ttsState.token) return;
    (function next(i) {
      if (token !== ttsState.token) return;
      if (i >= chunks.length) { clearSpeakingUI(); return; }
      var u = new SpeechSynthesisUtterance(chunks[i]);
      u.lang = pv.voice ? pv.voice.lang : (lang === 'fil' ? 'fil-PH' : 'en-US');
      if (pv.voice) u.voice = pv.voice;
      u.rate = 0.95;
      u.onend = function () { next(i + 1); };
      u.onerror = function () { if (token === ttsState.token) clearSpeakingUI(); };
      speechSynthesis.speak(u);
    })(0);
  }, 80);
}

if (TTS_OK) {
  speechSynthesis.onvoiceschanged = function () {};   // makes some browsers load the voice list
  speechSynthesis.getVoices();
}
window.addEventListener('pagehide', stopSpeech);
