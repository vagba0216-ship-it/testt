let map;

// =====================================================
// BALANGIGA RESQ MAP
// =====================================================

let balangigaBoundaryLayer = null;
let barangayBoundaryLayer = null;

let floodLayer = null;
let stormSurgeLayer = null;
let landslideLayer = null;
let shelterLayer = null;

let userLocationMarker = null;
let layerControl = null;


// -----------------------------------------------------
// BARANGAY RISK PROFILES
// -----------------------------------------------------

function getBarangayRiskProfile(barangay) {

  const profiles = {

    "Bacjao": [
      "Heavy rainfall",
      "Rain-induced landslide",
      "Localized flooding",
      "Typhoon winds"
    ],

    "Cag-olango": [
      "Heavy rainfall",
      "Rain-induced landslide",
      "Localized flooding",
      "Typhoon winds"
    ],

    "Cansumangcay": [
      "Heavy rainfall",
      "Rain-induced landslide",
      "Localized flooding",
      "Typhoon winds"
    ],

    "Guinmaayohan": [
      "Heavy rainfall",
      "Rain-induced landslide",
      "Localized flooding",
      "Typhoon winds"
    ],

    "Poblacion I": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Poblacion II": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Poblacion III": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Poblacion IV": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Poblacion V": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Poblacion VI": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "San Miguel": [
      "River flooding",
      "Coastal flooding",
      "Storm surge",
      "Tsunami"
    ],

    "Santa Rosa": [
      "Heavy rainfall",
      "Rain-induced landslide",
      "Localized flooding",
      "Typhoon winds"
    ],

    "Maybunga": [
      "Heavy rainfall",
      "Localized flooding",
      "Typhoon winds"
    ]

  };

  return profiles[barangay] || [
    "Heavy rainfall",
    "Typhoon winds"
  ];
}

function loadOfficialHazardLayers(boundaryLayer) {

  console.log(
    'Loading official hazard layers with Esri Leaflet...'
  );

  // =======================================================
  // FLOOD
  // =======================================================

  const floodURL =
    'https://controlmap.mgb.gov.ph/arcgis/rest/services/GeospatialDataInventory/GDI_Detailed_Flood_Susceptibility/MapServer/0';

  const floodFeatureLayer =
    L.esri.featureLayer({

      url: floodURL,

      useCors: false,

      fields: [
        'OBJECTID',
        'FloodSusc'
      ],

      simplifyFactor: 0.5,

      precision: 5,

      renderer: L.canvas(),

      style: function(feature) {

        const level =
          feature.properties?.FloodSusc;

        if (level === 'VHF') {
          return {
            color: '#991b1b',
            fillColor: '#ef4444',
            fillOpacity: 0.55,
            weight: 1
          };
        }

        if (level === 'HF') {
          return {
            color: '#c2410c',
            fillColor: '#f97316',
            fillOpacity: 0.50,
            weight: 1
          };
        }

        if (level === 'MF') {
          return {
            color: '#a16207',
            fillColor: '#facc15',
            fillOpacity: 0.45,
            weight: 1
          };
        }

        if (level === 'LF') {
          return {
            color: '#166534',
            fillColor: '#22c55e',
            fillOpacity: 0.35,
            weight: 1
          };
        }

        return {
          color: '#666',
          fillOpacity: 0.25,
          weight: 1
        };

      }

    });

    floodLayer.addLayer(floodFeatureLayer);


  // =======================================================
  // LANDSLIDE
  // =======================================================

  const landslideURL =
    'https://controlmap.mgb.gov.ph/arcgis/rest/services/GeospatialDataInventory/GDI_Detailed_Rain_induced_Landslide_Susceptibility/MapServer/0';

  const landslideFeatureLayer =
    L.esri.featureLayer({

      url: landslideURL,

      useCors: false,

      fields: [
        'OBJECTID',
        'LndslideSusc'
      ],

      simplifyFactor: 0.5,

      precision: 5,

      renderer: L.canvas(),

      style: function(feature) {

        const level =
          feature.properties?.LndslideSusc;

        if (level === 'VHL') {
          return {
            color: '#991b1b',
            fillColor: '#ef4444',
            fillOpacity: 0.55,
            weight: 1
          };
        }

        if (level === 'HL') {
          return {
            color: '#c2410c',
            fillColor: '#f97316',
            fillOpacity: 0.50,
            weight: 1
          };
        }

        if (level === 'ML') {
          return {
            color: '#a16207',
            fillColor: '#facc15',
            fillOpacity: 0.45,
            weight: 1
          };
        }

        if (level === 'LL') {
          return {
            color: '#166534',
            fillColor: '#22c55e',
            fillOpacity: 0.35,
            weight: 1
          };
        }

        if (level === 'DF') {
          return {
            color: '#581c87',
            fillColor: '#a855f7',
            fillOpacity: 0.40,
            weight: 1
          };
        }

        return {
          color: '#666',
          fillOpacity: 0.25,
          weight: 1
        };

      }

    });

    landslideLayer.addLayer(landslideFeatureLayer);


  // =======================================================
  // STORM SURGE
  // =======================================================

  const stormSurgeURLs = [
    {
      url:
        'https://services1.arcgis.com/IwZZTMxZCmAmFYvF/arcgis/rest/services/Storm_Surge_Hazard_Map/FeatureServer/1',
      name: 'Storm Surge 2.01–3m'
    },
    {
      url:
        'https://services1.arcgis.com/IwZZTMxZCmAmFYvF/arcgis/rest/services/Storm_Surge_Hazard_Map/FeatureServer/2',
      name: 'Storm Surge 3.01–4m'
    },
    {
      url:
        'https://services1.arcgis.com/IwZZTMxZCmAmFYvF/arcgis/rest/services/Storm_Surge_Hazard_Map/FeatureServer/3',
      name: 'Storm Surge 4.01–5m'
    },
    {
      url:
        'https://services1.arcgis.com/IwZZTMxZCmAmFYvF/arcgis/rest/services/Storm_Surge_Hazard_Map/FeatureServer/4',
      name: 'Storm Surge 5m+'
    }
  ];

  stormSurgeURLs.forEach(item => {

    const layer = L.esri.featureLayer({
      url: item.url,

      useCors: false,

      fields: [
        'OBJECTID',
        'HAZ'
      ],

      simplifyFactor: 1.0,

      precision: 4,

      minZoom: 14,

      renderer: L.canvas(),

      style: function(feature) {

        const level =
          Number(feature.properties?.HAZ);

        if (level === 1) {
          return {
            color: '#0369a1',
            fillColor: '#38bdf8',
            fillOpacity: 0.30,
            weight: 1
          };
        }

        if (level === 2) {
          return {
            color: '#1d4ed8',
            fillColor: '#3b82f6',
            fillOpacity: 0.35,
            weight: 1
          };
        }

        if (level === 3) {
          return {
            color: '#1e3a8a',
            fillColor: '#1d4ed8',
            fillOpacity: 0.40,
            weight: 1
          };
        }

        return {
          color: '#2563eb',
          fillColor: '#60a5fa',
          fillOpacity: 0.25,
          weight: 1
        };
      }
    });

    stormSurgeLayer.addLayer(layer);

  });

  console.log('Storm surge layers created.');


  console.log(
    'Official hazard layers created.'
  );

}

// -----------------------------------------------------
// MAP INITIALIZATION
// -----------------------------------------------------

window.onload = function() {

  const balangiga = [11.1105, 125.3833];

  map = L.map('map', {
    zoomControl: false,
    minZoom: 12,
    maxZoom: 18
  }).setView(balangiga, 14);

  L.control.zoom({
    position: 'bottomright'
  }).addTo(map);


  // ---------------------------------------------------
  // BASE MAP
  // ---------------------------------------------------

  L.tileLayer(
    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }
  ).addTo(map);


  // ---------------------------------------------------
  // EVACUATION CENTERS
  // ---------------------------------------------------

  shelterLayer = L.layerGroup();

  const shelterIcon = L.divIcon({

    className: '',

    html: `
      <div class="shelter-marker">
        <i data-lucide="building-2"
          style="width:18px;height:18px;">
        </i>
      </div>
    `,

    iconSize: [34,34],
    iconAnchor: [17,17]

  });


  L.marker(
    [11.10917, 125.38636],
    { icon: shelterIcon }
  )
  .bindPopup(`
    <b>Balangiga Municipal Hall</b><br>
    Evacuation Center<br>
    Capacity: 85 / 100
  `)
  .addTo(shelterLayer);


  L.marker(
    [11.11962, 125.38982],
    { icon: shelterIcon }
  )
  .bindPopup(`
    <b>Southern Samar National Comprehensive HS</b><br>
    Evacuation Center<br>
    Capacity: 120 / 500
  `)
  .addTo(shelterLayer);


  L.marker(
    [11.10956, 125.38812],
    { icon: shelterIcon }
  )
  .bindPopup(`
    <b>Balangiga Central Elementary School</b><br>
    Evacuation Center<br>
    Capacity: 249 / 250
  `)
  .addTo(shelterLayer);

  shelterLayer.addTo(map);

  // ---------------------------------------------------
  // OFFICIAL HAZARD LAYERS
  // ---------------------------------------------------

  floodLayer = L.layerGroup();
  stormSurgeLayer = L.layerGroup();
  landslideLayer = L.layerGroup();


  // ---------------------------------------------------
  // OFFICIAL BALANGIGA MUNICIPAL BOUNDARY
  // ---------------------------------------------------

  const boundaryURL =
    'https://ulap-nga.georisk.gov.ph/arcgis/rest/services/PSA/Municipal/MapServer/0/query' +
    '?where=city_name%3D%27Balangiga%27' +
    '&outFields=*' +
    '&returnGeometry=true' +
    '&outSR=4326' +
    '&f=geojson';


  fetch(boundaryURL)

    .then(response => response.json())

    .then(data => {

      if (!data.features || data.features.length === 0) {
        throw new Error('Balangiga boundary not found');
      }

      balangigaBoundaryLayer = L.geoJSON(data, {

        style: {
          color: '#ef4444',
          weight: 3,
          dashArray: '7 5',
          fillOpacity: 0
        }

      }).addTo(map);


      const balangigaBounds =
        balangigaBoundaryLayer.getBounds();


      map.fitBounds(
        balangigaBounds,
        {
          padding: [30,30]
        }
      );

      map.setMaxBounds(
        balangigaBounds.pad(0.15)
      );

      map.options.maxBoundsViscosity = 1.0;

      // LOAD OFFICIAL HAZARD DATA
      loadOfficialHazardLayers(
        balangigaBoundaryLayer
      );

    })

    .catch(error => {

      console.warn(
        'Could not load Balangiga boundary:',
        error
      );

      map.setView(
        balangiga,
        14
      );

    });


  // ---------------------------------------------------
  // OFFICIAL 13 BARANGAY BOUNDARIES
  // ---------------------------------------------------

  const barangayURL =
    'https://ulap-nga.georisk.gov.ph/arcgis/rest/services/PSA/BarangayPopMF/MapServer/0/query' +
    '?where=city_name%3D%27Balangiga%27' +
    '&outFields=brgy_name,city_name' +
    '&returnGeometry=true' +
    '&outSR=4326' +
    '&f=geojson';


  fetch(barangayURL)

    .then(response => response.json())

    .then(data => {

      if (!data.features || data.features.length === 0) {
        throw new Error('Barangay boundaries not found');
      }


      barangayBoundaryLayer = L.geoJSON(
        data,
        {

          style: {
            color: '#64748b',
            weight: 1,
            dashArray: '4 4',
            fillOpacity: 0
          },

          onEachFeature: function(feature, layer) {

            const barangay =
              feature.properties.brgy_name ||
              'Barangay';


            const risks =
              getBarangayRiskProfile(barangay);


            layer.bindPopup(`
              <b>${barangay}</b>
              <br><br>
              <b>Hazard Concerns</b><br>
              ${risks.map(r => `• ${r}`).join('<br>')}
              <br><br>
              <small>
                Prototype hazard profile.
              </small>
            `);

          }

        }
      );

      if (layerControl) {
        layerControl.addOverlay(
          barangayBoundaryLayer,
          '⬜ Barangay Boundaries'
        );
      }

    })

    .catch(error => {

      console.warn(
        'Could not load barangay boundaries:',
        error
      );

    });


  // ---------------------------------------------------
  // LAYER CONTROL
  // ---------------------------------------------------

  const overlays = {

    '🌊 Flood Risk': floodLayer,
    '🟠 Storm Surge': stormSurgeLayer,
    '🟡 Landslide Risk': landslideLayer,
    '🏫 Evacuation Centers': shelterLayer

  };


  layerControl = L.control.layers(
    null,
    overlays,
    {
      collapsed: true,
      position: 'topright'
    }
  ).addTo(map);


  // ---------------------------------------------------
  // INITIAL STATE
  // ---------------------------------------------------

  renderShelters();
  initGoBagState();

  setTimeout(() => {
    lucide.createIcons();
  }, 500);

};



// --- My Location ---
function locateUser() {

  if (!navigator.geolocation) {
    alert("Location services are not supported on this device.");
    return;
  }

  navigator.geolocation.getCurrentPosition(

    (position) => {

      const lat = position.coords.latitude;
      const lng = position.coords.longitude;

      if (userLocationMarker) {
        map.removeLayer(userLocationMarker);
      }

      const userIcon = L.divIcon({
        className: '',
        html: `<div class="user-location-marker"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9]
      });

      userLocationMarker = L.marker([lat, lng], {
        icon: userIcon
      })
      .addTo(map)
      .bindPopup("<b>Your Current Location</b>")
      .openPopup();

      map.setView([lat, lng], 16);

    },

    () => {
      alert("Unable to access your location. Please check your browser location permission.");
    },

    {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 30000
    }

  );
}
